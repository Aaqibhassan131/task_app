import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _phoneController = TextEditingController();
  bool isResendEnabled = false;

  Future<void> sendOtp() async {
    var url = Uri.parse('https://your-api.com/sendOtp');
    var response = await http.post(
      url,
      body: json.encode({'phone': _phoneController.text}),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode == 200) {
      setState(() {
        isResendEnabled = true;
      });
    } else {
      print('Failed to send OTP');
    }
  }

  Future<void> resendOtp() async {
    sendOtp();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _phoneController,
              decoration: InputDecoration(labelText: 'Enter Phone Number'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: sendOtp,
              child: Text('Send OTP'),
            ),
            if (isResendEnabled)
              TextButton(
                onPressed: resendOtp,
                child: Text('Resend OTP'),
              ),
          ],
        ),
      ),
    );
  }
}
