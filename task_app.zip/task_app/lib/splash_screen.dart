import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart'; // Required for kIsWeb

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  String deviceInfo = 'Fetching device info...';

  @override
  void initState() {
    super.initState();

    // Fetch device info based on platform
    if (kIsWeb) {
      // Handle Web case
      setState(() {
        deviceInfo = 'Web does not support device info.';
      });
    } else {
      // Handle native Android/iOS case
      _getDeviceInfo();
    }
  }

  // Function to get device info
  Future<void> _getDeviceInfo() async {
    final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
    String info = '';

    // Android and iOS specific code
    if (defaultTargetPlatform == TargetPlatform.android) {
      var androidInfo = await deviceInfoPlugin.androidInfo;
      info = 'Android Device: ${androidInfo.model}';
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      var iosInfo = await deviceInfoPlugin.iosInfo;
      info = 'iOS Device: ${iosInfo.utsname.machine}';
    }

    setState(() {
      deviceInfo = info;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Device Info")),
      body: Center(child: Text(deviceInfo)),
    );
  }
}
